# sysgraph lite

**Mermaid sekans diyagramları için görsel düzenleyici — tamamen tarayıcınızda, hesap gerekmeden.**
*A visual editor for Mermaid sequence diagrams — runs entirely in your browser, no account needed.*

Sürüm / Version: **0.1.0** (2026-11-02) · https://sysgraph.dev

## Kullanım

Arşivi açın ve `sysgraph-lite.html` dosyasını çift tıklayarak tarayıcıda açın. Kurulum, sunucu ya da internet
bağlantısı gerekmez; uygulama hiçbir ağ isteği yapmaz.

- Akışlar, klasörler, katalog ve roller bu tarayıcıda (IndexedDB) saklanır; hiçbir veri dışarı gönderilmez.
- Kayıtlar tarayıcıya ve dosyanın konumuna bağlıdır: dosyayı taşırsanız ya da yeni sürümü başka bir klasöre
  açarsanız eski kayıtlar görünmez. Yeni sürüme geçerken eski dosyanın yerine koyun ya da **Ayarlar › Veri ve
  yedekleme** bölümünden yedek alıp yeni dosyada geri yükleyin.
- Tarayıcı verisini temizlemek akışları siler; düzenli yedek alın (uygulama 7 günde bir hatırlatır).

Ekipçe çalışmak, bulutta saklamak ya da kurulumsuz kullanmak için: https://sysgraph.dev/app/
Dokümantasyon: https://sysgraph.dev/tr/docs/

## Usage

Unzip the archive and double-click `sysgraph-lite.html` to open it in your browser. No installation, server or
internet connection is needed; the app makes no network requests.

- Flows, folders, catalog and roles are stored in this browser (IndexedDB); nothing is sent anywhere.
- Storage is per browser and per file location: if you move the file or unzip a new version into another folder,
  the old data won't show. When updating, replace the old file in place, or back up in **Settings › Data and
  backup** and restore in the new file.
- Clearing browser data deletes your flows; back up regularly (the app reminds you every 7 days).

To work as a team, store in the cloud or use it without downloading: https://sysgraph.dev/app/
Documentation: https://sysgraph.dev/docs/

## Lisans / License

sysgraph lite ücretsizdir; kişisel ve ticari işlerde kullanılabilir. Kaynak kodu açık değildir; bu arşiv
yalnızca derlenmiş uygulamayı içerir. Ayrıntılar: LICENSE. Üçüncü taraf bileşenlerin lisansları:
THIRD_PARTY_NOTICES.txt.

sysgraph lite is free to use for personal and commercial work. It is not open source; this archive contains only
the built application. See LICENSE and THIRD_PARTY_NOTICES.txt.

Diagrams you create are yours. / Oluşturduğunuz diyagramlar size aittir.
